import "dotenv/config";
import express, { type Express, type Request, type Response, type NextFunction } from "express";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { appRouter } from "../routers";
import { createContext } from "./context";
import path from "path";
import fs from "fs";
import { addSecurityHeaders } from "./security";

/**
 * Resolve the Vite production build regardless of whether this module is
 * running from TypeScript source or from the bundled dist/index.js file.
 *
 * The previous implementation always walked two directories up from
 * import.meta.dirname. After esbuild bundles the server to dist/index.js,
 * import.meta.dirname is already the dist directory, so that calculation
 * points outside the project and causes Manus production startup to fail.
 */
function resolveFrontendDistPath(): string {
  const candidates = [
    path.resolve(process.cwd(), "dist", "public"),
    path.resolve(import.meta.dirname, "public"),
    path.resolve(import.meta.dirname, "../..", "dist", "public"),
  ];

  const resolved = candidates.find((candidate) =>
    fs.existsSync(path.join(candidate, "index.html"))
  );

  if (!resolved) {
    throw new Error(
      `[STARTUP ERROR] Frontend build not found. Checked: ${candidates.join(", ")}. Run 'pnpm build' before starting production.`
    );
  }

  return resolved;
}

/**
 * Create and configure the Express application.
 * This factory is used by both development (with Vite) and production (static files).
 * 
 * Route registration order is critical:
 * 1. Body parsers
 * 2. OAuth routes
 * 3. tRPC API routes
 * 4. Health check
 * 5. Error handling
 * 6. Static files (production only)
 * 7. SPA fallback (last)
 */
export function createApp(isDevelopment: boolean = false): Express {
  const app = express();

  // ============================================================================
  // MIDDLEWARE: Security Headers
  // ============================================================================
  addSecurityHeaders(app);

  // ============================================================================
  // MIDDLEWARE: Body Parsers
  // ============================================================================
  // Use route-specific limits instead of global 50MB
  app.use(express.json({ limit: "10mb" }));
  app.use(express.urlencoded({ limit: "10mb", extended: true }));

  // ============================================================================
  // ROUTES: Authentication & OAuth
  // ============================================================================
  registerOAuthRoutes(app);

  // ============================================================================
  // ROUTES: tRPC API
  // ============================================================================
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );

  // ============================================================================
  // ROUTES: Health Check
  // ============================================================================
  app.get("/api/health", (req: Request, res: Response) => {
    res.json({
      status: "ok",
      timestamp: new Date().toISOString(),
      environment: process.env.NODE_ENV || "development",
    });
  });

  // ============================================================================
  // MIDDLEWARE: Error Handling (centralized)
  // ============================================================================
  app.use((err: any, req: Request, res: Response, next: NextFunction) => {
    console.error("[Error]", err);

    // Don't expose internal errors to client
    const statusCode = err.statusCode || 500;
    const message =
      process.env.NODE_ENV === "production"
        ? "Internal server error"
        : err.message;

    res.status(statusCode).json({
      error: message,
      timestamp: new Date().toISOString(),
    });
  });

  // ============================================================================
  // ROUTES: Static Files (Production Only)
  // ============================================================================
  const productionDistPath = !isDevelopment
    ? resolveFrontendDistPath()
    : null;

  if (productionDistPath) {
    // Serve hashed assets with caching while keeping HTML revalidation-safe.
    app.use(
      express.static(productionDistPath, {
        maxAge: "1d",
        etag: true,
        index: false,
        setHeaders(res, filePath) {
          if (filePath.endsWith("index.html")) {
            res.setHeader("Cache-Control", "no-cache");
          }
        },
      })
    );
  }

  // ============================================================================
  // ROUTES: SPA Fallback (MUST BE LAST)
  // ============================================================================
  // Only serve index.html for browser requests, not API requests
  // In development, Vite middleware handles this; in production, we serve index.html
  if (!isDevelopment) {
    app.use((req: Request, res: Response) => {
      // If it's an API request that wasn't matched, return JSON 404
      if (req.path.startsWith("/api/")) {
        return res.status(404).json({
          error: "API endpoint not found",
          path: req.path,
          method: req.method,
        });
      }

      // For browser requests, serve index.html (SPA).
      if (!productionDistPath) {
        return res.status(503).json({ error: "Frontend build unavailable" });
      }

      res.setHeader("Cache-Control", "no-cache");
      return res.sendFile(path.join(productionDistPath, "index.html"));
    });
  }

  return app;
}
