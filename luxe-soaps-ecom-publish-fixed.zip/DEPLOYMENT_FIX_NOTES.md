# Luxe Soaps deployment fix

## Confirmed production blocker

The production server bundle is emitted as `dist/index.js`. In that bundle,
`import.meta.dirname` is the project's `dist` directory. The previous static-file
calculation walked two directories upward and then appended `dist/public`, which
resolved outside the project. The server then exited with "Frontend build not
found" even after a successful Vite build.

The app now resolves `dist/public` safely from multiple valid runtime locations
and verifies that `index.html` exists before serving it.

## Additional corrections

- Local HTTP auth cookies now use `SameSite=Lax`; HTTPS production cookies use
  `SameSite=None; Secure`.
- OAuth sessions no longer fail solely because a provider returned an empty
  display name.
- The redundant `pnpm` package was removed from devDependencies.
- Node 20 through 24 is declared as the supported runtime range.

## Publish commands

```bash
pnpm install --frozen-lockfile
pnpm check
pnpm test
pnpm build
pnpm start
```

The Manus production start command remains:

```bash
NODE_ENV=production node dist/index.js
```

## Important store status

The live sales flow currently relies primarily on external Stripe Payment Links
from the Home and Shop pages. The included Cart and Checkout screens are mock UI:
they are not registered in `App.tsx`, do not persist real cart data, do not write
orders to the database, and the checkout form is not connected to Stripe. Do not
route customers to that mock checkout or collect card details through it.
